import { GlobalAdvariable } from './GlobalAdvariable';

export let GlobalAdVar:GlobalAdvariable;

export function setAdGlobalVar(globaladvar)
{
GlobalAdVar=globaladvar;
}