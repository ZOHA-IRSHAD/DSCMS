export interface ItemsOfFeedback {
    "vendor_id": string,
    "vendor_name": string,
    "item_id":string,
    "item_name":string,
    "category_id": string,
    "quality_of_service": string,
    "quality_of_food" : string,
    "remarks": string,
    "serving_id" : string
}
