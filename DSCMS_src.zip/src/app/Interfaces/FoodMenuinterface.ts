export interface FoodMenuinterface {
    vendorId : string,
    vendorName : string,
    item_id : string,
    foodItems : string,
    categoryId : string,
    categoryName : string,
    ratePerPlate : number,
    serving_id : string

}
