 export interface Globalvariable {
    _id:string; 
    vendor_name:any;
    contact_person:string;
    email_address:string;
    contact_number:number;
    service_start_date:Date;
    service_end_date:Date;
    vendor_address:string;
    location_id:string;
    food_cat:any[];
    time_of_service_id:any[];
    
}
