export interface ItemsOfOrder {

        vendor_id : string,
        vendor_name : string,
        item_id : string,
        item_name : string,
        category_id : string,
        category_name : string,
        quantity : number,
        amount : number,
        serving_id : string 
}





  
           
        