import { AppError } from "./app-error";

export class ConnectionTimeOut extends AppError {

}