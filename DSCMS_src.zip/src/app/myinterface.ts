export interface Myinterface {
    foodItems : string,
    ratePerPlate : number
    
}
