export interface User {
    oldpassword: string;
    password: string;
    confirmPassword: string;
}
