import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-exception',
  templateUrl: './show-exception.component.html',
  styleUrls: ['./show-exception.component.css']
})
export class ShowExceptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
