export interface Image{
   
image_url:File;
}