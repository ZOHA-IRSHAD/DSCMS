export interface GlobalAdvariable{
    _id:string;
    ad_name:string;
    contact_employee:string;
    email:string;
    phone:number;
    ad_start_date:Date;
    ad_end_date:Date;
    status:string;
    

}