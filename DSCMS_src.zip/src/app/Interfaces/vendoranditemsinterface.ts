export interface Vendoranditemsinterface {

    vendor_name : string,
    items_name : string[]
}
