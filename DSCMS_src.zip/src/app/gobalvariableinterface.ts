import { Globalvariable } from './globalvariable';

export let GlobalVar:Globalvariable;

export function setGlobalVar(globalvar)
{
GlobalVar=globalvar;
}