import { GlobalLocvariable } from './Globallocvariable';

export let GloballocVar:GlobalLocvariable;

export function setlocGlobalVar(globallocvar)
{
GloballocVar=globallocvar;
}