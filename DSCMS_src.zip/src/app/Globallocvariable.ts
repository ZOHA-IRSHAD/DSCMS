export interface GlobalLocvariable{
  
    location_name:string;
    campus:string;
    

}