import { Image } from './image';

export let ImageVar:Image;

export function setImage(imagevar)
{
ImageVar=imagevar;
}